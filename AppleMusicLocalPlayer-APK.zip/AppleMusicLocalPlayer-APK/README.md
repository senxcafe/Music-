# Local Music — APK project

Android WebView APK version of the Apple-Music-inspired local music player.

Features included in the packaged HTML: local audio selection, favorites, shuffle, repeat, search, swipe next/previous, full now-playing sheet, progress seeking, queue info, MediaSession controls, and the Dynamic notification bar.

## Build in GitHub (no Android Studio)
1. Create a new GitHub repository.
2. Upload all files from this project, preserving folders.
3. Commit to the `main` branch.
4. Open **Actions → Build APK**.
5. Run the workflow (or push a commit).
6. Open the completed workflow → **Artifacts** → `Local-Music-debug-apk`.
7. Download and install `app-debug.apk` on the Android phone.

The app is designed for Android 11 and newer. The Android file picker is used for selecting local audio files, so the app does not upload the songs to a server.
